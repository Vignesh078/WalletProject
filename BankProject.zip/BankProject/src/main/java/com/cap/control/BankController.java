package com.cap.control;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class BankController {

	@RequestMapping("/validateLogin")
	public String validateLogin ( 
			@RequestParam("userName") String usrname,
			@RequestParam("passWord") String usrpass) {
			if(usrname.equals("Vicky") && usrpass.equals("1234")) {
				
				return "contentPage";
		}
			
			return "redirect:/";
			
	}
	@RequestMapping("/createAccount")
	public String showCreatePage() {
		return "createPage";
	}
}

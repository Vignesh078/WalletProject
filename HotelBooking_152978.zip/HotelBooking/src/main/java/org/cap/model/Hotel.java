package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Table(name="hotelDetails")
@Entity
public class Hotel {
    @Id
    @GeneratedValue
	private int hotelId;
	private String hotelName;
	private String hotelRating;
	private int hotelRate;
	private int availableRooms;
	
	public Hotel() {
		
	}
	
	public Hotel(int hotelId, String hotelName, String hotelRating, int hotelRate, int availableRooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelRating = hotelRating;
		this.hotelRate = hotelRate;
		this.availableRooms = availableRooms;
	}
	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", hotelRating=" + hotelRating
				+ ", hotelRate=" + hotelRate + ", availableRooms=" + availableRooms + "]";
	}
	public int getHotelId() {
		return hotelId;
	}
	
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelRating() {
		return hotelRating;
	}
	public void setHotelRating(String hotelRating) {
		this.hotelRating = hotelRating;
	}
	public int getHotelRate() {
		return hotelRate;
	}
	public void setHotelRate(int hotelRate) {
		this.hotelRate = hotelRate;
	}
	public int getAvailableRooms() {
		return availableRooms;
	}
	public void setAvailableRooms(int availableRooms) {
		this.availableRooms = availableRooms;
	}
	
	
}

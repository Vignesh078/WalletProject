package org.cap.service;

import java.util.List;

import org.cap.model.Hotel;

public interface IHotelService {

	public List<Hotel> getAllHotels();

}

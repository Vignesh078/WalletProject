package org.cap.service;

import java.util.List;

import org.cap.dao.IHotelDao;
import org.cap.model.Hotel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("hotelService")
public class HotelServiceImpl implements IHotelService {
	@Autowired
	private IHotelDao hotelDao;
	@Override
	public List<Hotel> getAllHotels() {
		return hotelDao.getAllHotels();
	}

}

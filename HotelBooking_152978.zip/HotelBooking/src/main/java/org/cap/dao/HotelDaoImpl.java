package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Hotel;
import org.springframework.stereotype.Repository;

@Repository("hotelDao")
public class HotelDaoImpl implements IHotelDao {
	@PersistenceContext
	private EntityManager entityManager;
	@Transactional
	@Override
	public List<Hotel> getAllHotels() {
		List<Hotel> hotels = entityManager.createQuery("from Hotel").getResultList();
		return hotels;
	}

}

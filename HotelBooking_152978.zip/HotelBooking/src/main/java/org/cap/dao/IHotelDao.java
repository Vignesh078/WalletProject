package org.cap.dao;

import java.util.List;

import org.cap.model.Hotel;

public interface IHotelDao {

	public List<Hotel> getAllHotels();

}

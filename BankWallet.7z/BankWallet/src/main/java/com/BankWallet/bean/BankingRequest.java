package com.BankWallet.bean;

public class BankingRequest {

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String name;
	public int getAccno() {
		return Accno;
	}
	public void setAccno(int accno) {
		Accno = accno;
	}
	public  String address;
	public BankingRequest(String name, String address, String mobileno, String passwd, int accno, String transact,
			Float balance) {
		super();
		this.name = name;
		this.address = address;
		this.mobileno = mobileno;
		this.passwd = passwd;
		Accno = accno;
		transactions = transact;
		Balance = balance;
	}
	public String mobileno;
	public String passwd;
	public int Accno;
	public String transactions;
	
	public Float Balance;
	
	public String getTransactions() {
		return transactions;
	}
	public void setTransactions(String transact) {
		transactions = transact;
	}
	public Float getBalance() {
		return Balance;
	}
	public void setBalance(Float balance) {
		Balance = balance;
	}
	public BankingRequest() {
		
		name=null;
		address=null;
		mobileno=null;
		passwd=null;
		Accno=0;
		transactions=null;
		Balance=0.0f;
	}
}

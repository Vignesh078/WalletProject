package com.BankWallet.Test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.BankWallet.Exception.BankingException;
import com.BankWallet.Service.WalletService;
import com.BankWallet.Service.WalletServiceImpl;

public class BankingDaoImplTest {
    WalletService ws = new WalletServiceImpl();
	@Test
	public void testCreateAccount() {
		try {
			assertEquals(ws.createAccount("Vicky", "pass3"),103);
		} catch(BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testLogin() {
		try {
			assertEquals(ws.login(102,"pass2"),true);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetBalance() {
		try {
			assertEquals(ws.getBalance(101),500,0.0);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testDeposit() {
		try {
			assertEquals(ws.deposit(102,3000),3700,0.0);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testWithdraw() {
		try {
			assertEquals(ws.withdraw(102,200),700,0.0);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}
	@Test
	public void testTransfer() {
		try {
			assertEquals(ws.transfer(101,102,0),true);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testPrintDetails() {
		try {
			assertEquals(ws.printDetails(101),"No transactions present");
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}

}
}

package com.BankWallet;

import java.util.Scanner;

import com.BankWallet.Exception.BankingException;
import com.BankWallet.Service.WalletService;
import com.BankWallet.Service.WalletServiceImpl;
import com.BankWallet.bean.BankingRequest;

/**
 * Hello world!
 *
 */
public class App 
{
	 Scanner s=new Scanner(System.in);
	 BankingRequest b=new BankingRequest();
    WalletService si=new WalletServiceImpl();
    static int accno;
    static float balance;
   
	static int transno=0;
    public static void main( String[] args )
    {
    	
    	 boolean flag = false;
    	App a=new App();
    	
		String option=null;
		while(true) {
			System.out.println("||||||||||Welcome to XYZ Bank|||||||||||||");
		    System.out.println("Press 1 to register");
		    System.out.println("Press 2 to login");
		    Scanner s=new Scanner(System.in);
		    int i=s.nextInt();
		    if(i==2)  {
			System.out.println("Enter your account number");
   			accno=Integer.parseInt(a.s.nextLine());
			System.out.println("Enter your password");
			String password=s.next();
			try {
				 WalletService si=new WalletServiceImpl();
				flag = si.login(accno,password);
			} catch (BankingException e) {
				System.err.println(e.getMessage());
			}
			
		}
		    else if(i==1)
		    {
		    	BankingRequest b=new BankingRequest();
		    	int id = 0;
		    	System.out.println("Enter your Name");
		    	b.setName(s.next());
		    	System.out.println("Enter your address");
		    	b.setAddress(s.next());
		    	System.out.println("Enter your Mobile No");
		    	b.setMobileno(s.next());
		    	System.out.println("Enter the password");
		    	b.setPasswd(s.next());
		    	try {
		    	  WalletService si=new WalletServiceImpl();
				  id=si.createAccount(b.getName(), b.getPasswd());
				} catch (BankingException e) {
					System.err.println(e.getMessage());
				}
		    	System.out.println("Bank Account successfully registered with Account No:" +id); 	
		    } else
		    {
		    	System.out.println("Invalid option");
		    }
	
		while(flag) {   
		System.out.println("===================Banking Application=================");
		System.out.println("1:Show Balance");
		System.out.println("2:Deposit");
		System.out.println("3:Withdraw");
		System.out.println("4:Fund Transfer");
		System.out.println("5:Print Transactions");
		System.out.println("Enter your choice:");
		String choice=s.next();
		switch(choice) {
		case "1":
			a.displayBal(accno);
			break;
		case "2":
			a.deposit(accno);
			break;
		case "3":
			a.withdraw(accno);
			break;
		case "4":
			a.transfer(accno);
			break;
		case "5":
			a.printDetails(accno);
		    break;
		default:
			System.out.println("Enter a valid option");
		}
		
		}
		}
    }
	private void printDetails(int accno) {
		try {
			String st=si.printDetails(accno);
			System.out.println("Transaction Details:"+st);
			
		}catch (BankingException e) {
			System.err.println(e.getMessage());
		}
	}
	private void transfer(int accno) {
		try {
			System.out.println("Enter the Account Number to which you want to transfer");
			int accno2=Integer.parseInt(s.nextLine());
			System.out.println("Enter the amount to be transfered");
			Float input=Float.parseFloat(s.nextLine());
			boolean result=si.transfer(accno, accno2, input);
			if(result) {
				System.out.println("Transaction complete");
		
			}
		}catch (BankingException e) {
			System.err.println(e.getMessage());
		}
		
	}
	private void withdraw(int accno) {
		try {
			System.out.println("Enter the amount to be withdrawn");
			Float input=Float.parseFloat(s.nextLine());
			balance=si.withdraw(accno, input);
			System.out.println("Account Number:" +accno);
			System.out.println("Updated Balance:" +balance);
		
		} catch (BankingException e) {
			System.err.println(e.getMessage());
		}
	}
	private void deposit(int accno) {
		
		try {
			System.out.println("Enter the amount to be deposited");
			Float input=Float.parseFloat(s.nextLine());
			balance=si.deposit(accno, input);
			System.out.println("Account Number:" +accno);
			System.out.println("Updated Balance:" +balance);
			
		} catch (BankingException e) {
			System.err.println(e.getMessage());
		}
		
	}
	private void displayBal(int accno) {
		try {
			balance=si.getBalance(accno);
			System.out.println("Account Number:" +accno);
			System.out.println("Balance:" +balance);
		} catch (BankingException e) {
			System.err.println(e.getMessage());
		}
		
	}
}


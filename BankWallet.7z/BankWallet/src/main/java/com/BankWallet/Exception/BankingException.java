package com.BankWallet.Exception;

public class BankingException extends Exception{
	public BankingException() {
		super();
	}
	public BankingException(String message) {
		super(message);
	}
}

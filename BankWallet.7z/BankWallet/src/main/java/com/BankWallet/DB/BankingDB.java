package com.BankWallet.DB;

import java.util.HashMap;

import com.BankWallet.bean.BankingRequest;

public class BankingDB {
public static HashMap <Integer, BankingRequest> bankmap=new HashMap<Integer, BankingRequest>();
static {

	bankmap.put(101, new BankingRequest("Vicky","chennai","9094829546","pass1", 101,null,500.0f));
	bankmap.put(102, new BankingRequest("Vaishu","Mumbai","9023482348","pass2", 102,null,900.0f));
}
public static HashMap <Integer, BankingRequest> getAccountMap() {
	return bankmap;
}
}

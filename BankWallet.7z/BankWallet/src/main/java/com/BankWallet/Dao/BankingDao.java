package com.BankWallet.Dao;

import com.BankWallet.Exception.BankingException;

public interface BankingDao {
int createAccount(String name, String passwd) throws BankingException;
boolean login(int accno, String passwd) throws BankingException;
float getBalance(int accno) throws BankingException;
float deposit(int accno, float input) throws BankingException;
float withdraw(int accno, float input) throws BankingException;
boolean transfer(int accno,int accno2, float input) throws BankingException;
String printDetails(int accno) throws BankingException;
}

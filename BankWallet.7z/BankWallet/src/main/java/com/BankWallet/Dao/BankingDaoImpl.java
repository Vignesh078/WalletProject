package com.BankWallet.Dao;

import java.io.File;
import java.util.HashMap;
import java.util.Optional;

import com.BankWallet.DB.BankingDB;
import com.BankWallet.Exception.BankingException;
import com.BankWallet.bean.BankingRequest;

public class BankingDaoImpl implements BankingDao {
	
     static HashMap<Integer, BankingRequest> bankmap=BankingDB.getAccountMap();
     BankingRequest b=new BankingRequest();
	public int createAccount(String name, String passwd) throws BankingException {
		int reqid;
		try {
			if(bankmap.size()==0) {
				reqid=100;
				b.setAccno(reqid);
			}
			else {
				Optional<Integer> id=bankmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				reqid=id.get()+1;
				b.setAccno(reqid);
			}
			BankingRequest br=new BankingRequest();
			bankmap.put(b.getAccno(), br);
			return b.getAccno();
		} catch(Exception e) {
			throw new BankingException(e.getMessage());
		}
	}
	
	@Override
	public boolean login(int accno, String passwd) throws BankingException {
		BankingRequest br=new BankingRequest();
		try {
			br=bankmap.get(accno);
			if(br==null) {
				throw new BankingException("Invalid Account number");
			}
			if(!br.getPasswd().equals(passwd)) {
				throw new BankingException("Incorrect Password!!!!!!!!!!");
			}
			return true;
		} catch(Exception e) {
			throw new BankingException(e.getMessage());
		}
	}
	@Override
	public float getBalance(int accno) throws BankingException {
		BankingRequest br=new BankingRequest();
		try {
			br=bankmap.get(accno);
			return br.getBalance();
		} catch( Exception e) {
			throw new BankingException(e.getMessage());
		}
	}
	@Override
	public float deposit(int accno, float input) throws BankingException {
		BankingRequest br=new BankingRequest();
		try {
			br=bankmap.get(accno);
			float sal=br.getBalance();
			sal+=input;
			br.setBalance(sal);
			br.setTransactions("An amount of "+input+ "has been deposited");
			bankmap.put(accno, br);
			return br.getBalance();
			
			
		} catch( Exception e) {
			throw new BankingException(e.getMessage());
		}
	}
	@Override
	public float withdraw(int accno, float input) throws BankingException {
		BankingRequest br=new BankingRequest();
		try {
			br=bankmap.get(accno);
			float sal=br.getBalance();
			sal-=input;
			br.setBalance(sal);
			br.setTransactions("An amount of "+input+ "has been withdrawn");
			bankmap.put(accno, br);
			return br.getBalance();
		} catch( Exception e) {
			throw new BankingException(e.getMessage());
		}
	}
	@Override
	public boolean transfer(int accno, int accno2, float input) throws BankingException {
		BankingRequest br=new BankingRequest();
		BankingRequest br1=new BankingRequest();
		try {
			br=bankmap.get(accno);
			float sal=br.getBalance();
			System.out.println("Initial Balance in "+accno+ "is " +sal);
			sal-=input;
			br.setBalance(sal);
			br.setTransactions("An amount of "+input+ "has been transferred out");
			bankmap.put(accno, br);
			
			System.out.println("Updated Balance in "+accno+ "is " +br.getBalance());
			br1 = bankmap.get(accno2);
			
			sal=br1.getBalance();
			System.out.println("Initial Balance in "+accno2+ "is " +sal);
			sal+=input;
			br1.setBalance(sal);
			br1.setTransactions("An amount of "+input+ "has been transferred in");
			bankmap.put(accno, br1);
			
			System.out.println("Updated  Balance in "+accno2+ "is " +br1.getBalance());
			return true;
		} catch( Exception e) {
			throw new BankingException(e.getMessage());
		}
	}

	@Override
	public String printDetails(int accno) throws BankingException {
		
		String str="No transactions present";
		try {
			b = bankmap.get(accno);
			if(b.getTransactions()==null) {
				return str;
			}
			else {
			return b.getTransactions(); }
	} catch( Exception e) {
		throw new BankingException(e.getMessage());
	}

}
}
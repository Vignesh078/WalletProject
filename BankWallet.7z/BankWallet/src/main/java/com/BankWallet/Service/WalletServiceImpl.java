package com.BankWallet.Service;

import com.BankWallet.Dao.BankingDao;
import com.BankWallet.Dao.BankingDaoImpl;
import com.BankWallet.Exception.BankingException;

public class WalletServiceImpl implements WalletService {
    BankingDao bd=new BankingDaoImpl();
	@Override
	public int createAccount(String name, String passwd) throws BankingException {
		// TODO Auto-generated method stub
		return bd.createAccount(name, passwd);
	}

	@Override
	public boolean login(int accno, String passwd) throws BankingException {
		// TODO Auto-generated method stub
		return bd.login(accno, passwd);
	}

	@Override
	public float getBalance(int accno) throws BankingException {
		// TODO Auto-generated method stub
		return bd.getBalance(accno);
	}

	@Override
	public float deposit(int accno, float input) throws BankingException {
		// TODO Auto-generated method stub
		return bd.deposit(accno, input);
	}

	@Override
	public float withdraw(int accno, float input) throws BankingException {
		// TODO Auto-generated method stub
		return bd.withdraw(accno, input);
	}

	@Override
	public boolean transfer(int accno, int accno2, float input) throws BankingException {
		// TODO Auto-generated method stub
		return bd.transfer(accno, accno2, input);
	}

	@Override
	public String printDetails(int accno) throws BankingException {
		// TODO Auto-generated method stub
		return bd.printDetails(accno);
	}

	

}

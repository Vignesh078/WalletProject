package com.BankWallet.Dao;



public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO customer VALUES(CUSTOMER_SEQUENCE.NEXTVAL,?,?,?,?,?,?)";
	public static final String INSERT_TRANSACTION="INSERT INTO TRANSACTION VALUES(transaction_sequence.NEXTVAL,?,?,?)";
	public static final String UPDATE_CUSTOMER_DEPOSIT="UPDATE customer SET balance = balance + ? WHERE accno= ?";
	public static final String UPDATE_CUSTOMER_WITHDRAW="UPDATE customer SET balance = balance - ? WHERE accno= ?";
	public static final String VIEW_BALANCE_CUSTOMER="SELECT balance FROM customer WHERE accno=?";
	public static final String PRINT_TRANSACTION="SELECT trid,accno,amount,trtype FROM transaction WHERE accno=?";
	public static final String GET_PIN_CUSTOMER="SELECT password FROM customer WHERE accno=?";
	public static final String transfer_query1="insert into transfer values(transid_sequence.NEXTVAL,?,?,?,?)";
	public static final String date_query="select sysdate from dual";
    public static final String transfer_query_sequence="select transid_sequence.CURRVAL from dual";
    public static final String transfer_query2="select * from transfer where accountno=?";
}

/******************TABLESCRIPT*******************
CREATE TABLE customer(
accno number(10),
name varchar2(30),
mobile varchar2(30),
address varchar2(30),
password varchar2(30),
balance float,
transaction varchar2(30)
);

CREATE SEQUENCE CUSTOMER_SEQUENCE start with 1 increment by 1;

************************************************/
package com.BankWallet.Dao;

import com.BankWallet.Exception.BankingException;
import com.BankWallet.bean.BankingRequest;

public interface BankingDao {
int createAccount(BankingRequest request) throws BankingException;
boolean login(int accno, String passwd) throws BankingException;
float getBalance(int accno) throws BankingException;
float deposit(int accno, float input) throws BankingException;
float withdraw(int accno, float input) throws BankingException;
boolean transfer(int accno,int accno2, float input) throws BankingException;
boolean printDetails(int accno) throws BankingException;
}

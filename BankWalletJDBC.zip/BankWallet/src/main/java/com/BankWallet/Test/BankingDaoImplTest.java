package com.BankWallet.Test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.BankWallet.Exception.BankingException;
import com.BankWallet.Service.WalletService;
import com.BankWallet.Service.WalletServiceImpl;
import com.BankWallet.bean.BankingRequest;

public class BankingDaoImplTest {
    WalletService ws = new WalletServiceImpl();
	@Test
	public void testCreateAccount() {
		try {
			BankingRequest br = new BankingRequest();
			br.setName("Vicky");
			br.setPasswd("passwd");
			br.setMobileno("12345");
			assertNotEquals(ws.createAccount(br),22);
			
			
		} catch(BankingException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testLogin() {
		try {
			assertEquals(ws.login(1,"qwerty"),true);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetBalance() {
		try {
			assertEquals(ws.getBalance(22),-3000,0.0);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testDeposit() {
		try {
			assertEquals(ws.deposit(22,3000),1,0.0);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testWithdraw() {
		try {
			assertEquals(ws.withdraw(22,3000),1,0.0);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}
	@Test
	public void testTransfer() {
		try {
			assertEquals(ws.transfer(22,1,0),true);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testPrintDetails() {
		try {
			assertEquals(ws.printDetails(1),false);
		} catch(BankingException e) {
			System.out.println(e.getMessage());
		}

}
}

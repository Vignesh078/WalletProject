package com.BankWallet.Exception;

public class BankingException extends Exception  {
	private static final long serialVersionUID = 726264577455921591L;

	public BankingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}

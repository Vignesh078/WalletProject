package com.BankWallet.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.BankWallet.Transfer;
import com.BankWallet.Exception.BankingException;
import com.BankWallet.bean.BankingRequest;
import com.BankWalletDB.DBConnection;


public class BankingDaoImpl implements BankingDao {
	
	Logger logger=Logger.getRootLogger();
     BankingRequest b=new BankingRequest();
     int transid=0;
     public BankingDaoImpl() {
 		
 		PropertyConfigurator.configure("resources//log4j.properties");
 	}

     @SuppressWarnings("resource")
	public boolean login(int accno, String passwd) throws BankingException {
		 Connection connection = DBConnection.getInstance().getConnection();	
		 PreparedStatement preparedStatement=null;		
		 ResultSet rs=null;
		 String result=null;
		 try {
			  preparedStatement=connection.prepareStatement(QueryMapper.GET_PIN_CUSTOMER);
			  preparedStatement.setInt(1, accno);
			  rs=preparedStatement.executeQuery();
			  rs.next();
			  result=rs.getString("password");
		 } catch(SQLException e) {
			 logger.error(e.getMessage());
			 e.printStackTrace();
			 throw new BankingException("Technical problem occured refer log");
		 }
		 finally
	 		{
	 			try 
	 			{
	 				preparedStatement.close();
	 				connection.close();
	 			}
	 			catch (SQLException e2) 
	 			{
	 				logger.error(e2.getMessage());
	 				throw new BankingException("Error in closing db connection");	
	 			}
	 		}	
		 try {
			 if(!result.equals(passwd)) {
				 throw new BankingException("Incorrect Password");
			 }
				 return true;
		 } catch(BankingException e) {
			 throw new BankingException(e.getMessage());
		 }
	}
	public float getBalance(int accno) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement prepareStatement = null;
		ResultSet rs = null;
		try {
			prepareStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			prepareStatement.setInt(1, accno);
			rs = prepareStatement.executeQuery();
			rs.next();
			float result = rs.getFloat("balance");
			return result;
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new BankingException("Technical problem occured refer log");
		}
		finally {
			try {
				prepareStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new BankingException("Error in closing DB connection");
			}			
		}
	}
		
	public boolean deposit(int accno, float input) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement prepareStatement = null;
		PreparedStatement prepareStatement1=null;
		ResultSet resultSet=null,resultSet2=null;
		int queryResult=0,queryresult1=0;
		try {
			prepareStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
			prepareStatement.setFloat(1, input);
			prepareStatement.setLong(2, accno);
			queryResult = prepareStatement.executeUpdate();
			prepareStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			prepareStatement.setInt(1,accno);
			resultSet=prepareStatement.executeQuery();

			if(resultSet.next())
			{
				double balance= resultSet.getDouble("Balance");
				prepareStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
				prepareStatement1.setString(1,"deposit");
				prepareStatement1.setDouble(2,input);
				prepareStatement1.setLong(4,accno);
				PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
				resultSet2=Date.executeQuery();
				if(resultSet2.next())
				{
					Date date=resultSet2.getDate(1);
					prepareStatement1.setDate(3, date);
					
				}
				queryresult1=prepareStatement1.executeUpdate();
				prepareStatement = connection.prepareStatement(QueryMapper.transfer_query_sequence);
				resultSet=prepareStatement.executeQuery();

				if(resultSet.next())
				{
					transid=resultSet.getInt(1);
							
				}
			}
			else
			{
				throw new BankingException("Enter correct account number and pin");
			}
			return true;			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new BankingException("Technical problem occured refer log");
		}
		finally {
			try {
				prepareStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new BankingException("Error in closing DB connection");
			}			
		}
	}
		
	public boolean withdraw(int accno, float input) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet=null,resultSet2=null;
		int queryresult=0;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
			preparedStatement.setInt(1,accno);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
			float balance1= resultSet.getFloat("Balance");
			if(balance1<input)
					throw new BankingException("insufficient balance in your account");
			else
			{	
				preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
				preparedStatement.setFloat(1, input);
				preparedStatement.setInt(2, accno);
				queryresult = preparedStatement.executeUpdate();
				preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
				preparedStatement.setInt(1,accno);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next())
				{
					float balance= resultSet.getFloat("Balance");
					preparedStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
					preparedStatement1.setString(1,"withdraw");
					preparedStatement1.setFloat(2,input);
					preparedStatement1.setInt(4,accno);
					PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
					resultSet2=Date.executeQuery();
					if(resultSet2.next())
					{
						Date date=resultSet2.getDate(1);
						preparedStatement1.setDate(3,date);
						
					}
					queryresult=preparedStatement1.executeUpdate();
					preparedStatement = connection.prepareStatement(QueryMapper.transfer_query_sequence);
					resultSet=preparedStatement.executeQuery();

					if(resultSet.next())
					{
						transid= resultSet.getInt(1);
								
					}
				}else
					throw new BankingException("invalid details");
			}
			}else
				throw new BankingException("invalid details");
			return true;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new BankingException("Technical problem occured refer log");
		}
		finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e2) {
				logger.error(e2.getMessage());
				throw new BankingException("Error in closing DB connection");
			}			
		}
	}	
	
	public boolean transfer(int accno, int accno2, float input) throws BankingException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		PreparedStatement preparedStatement1=null;	
		ResultSet resultSet2 = null;
		int queryResult=0;
				if(input<=0)
					throw new BankingException("for fund to be transfered fund must be greater than 0");
				else
				{
				try
				{
					
					preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
					preparedStatement.setInt(1,accno);
					resultSet=preparedStatement.executeQuery();
					if(resultSet.next())
					{
					double balance1= resultSet.getDouble("Balance");
					if(balance1<input)
							throw new BankingException("Low balance for fundtranfer");
					
					else 
						{
						
						preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_WITHDRAW);
						preparedStatement.setFloat(1, input);
						preparedStatement.setInt(2, accno);
						queryResult = preparedStatement.executeUpdate();
						
						preparedStatement1=connection.prepareStatement(QueryMapper.UPDATE_CUSTOMER_DEPOSIT);
						preparedStatement1.setFloat(1, input);
						preparedStatement1.setInt(2, accno2);
						queryResult = preparedStatement1.executeUpdate();
						
						preparedStatement=connection.prepareStatement(QueryMapper.VIEW_BALANCE_CUSTOMER);
						preparedStatement.setInt(1,accno2);
						resultSet=preparedStatement.executeQuery();
						if(resultSet.next())
						{
						float balance2= resultSet.getFloat("Balance");
						preparedStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
						preparedStatement1.setString(1,"fundtransfer(DB)");
						preparedStatement1.setFloat(2,input);
						preparedStatement1.setInt(4,accno2);
						PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
						resultSet2=Date.executeQuery();
						if(resultSet2.next())
						{
							Date date=resultSet2.getDate(1);
							preparedStatement1.setDate(3,date);
							
						}
						queryResult=preparedStatement1.executeUpdate();
						preparedStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
						preparedStatement1.setString(1,"fundtransfer(cr)");
						preparedStatement1.setFloat(2,input);
						preparedStatement1.setInt(4,accno);
						PreparedStatement date1=connection.prepareStatement(QueryMapper.date_query);
						resultSet2=date1.executeQuery();
						if(resultSet2.next())
						{
							Date d=resultSet2.getDate(1);
							preparedStatement1.setDate(3,d);
						}
						queryResult=preparedStatement1.executeUpdate();
						preparedStatement = connection.prepareStatement(QueryMapper.transfer_query_sequence);
						resultSet=preparedStatement.executeQuery();

						if(resultSet.next())
						{
							transid= resultSet.getInt(1);
									
						}
						return true;
						}else
							throw new BankingException("invalid account detailsdetails");
					}
					}else
						throw new BankingException("invalid details");
				}
					catch(SQLException sqlException)
				{
				logger.error(sqlException.getMessage());
				sqlException.printStackTrace();
				throw new BankingException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new BankingException("Error in closing db connection");	
				}
			}
		}		
	}

	public int createAccount(BankingRequest customer) throws BankingException {
		 Connection connection = DBConnection.getInstance().getConnection();	
	 		
	 		PreparedStatement preparedStatement=null;		
	 		int queryResult=0;
	 		try
	 		{		
	 			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

	 			preparedStatement.setString(1,customer.getName());
	 			preparedStatement.setString(2,customer.getMobileno());
	 			preparedStatement.setString(3,customer.getAddress());
	 			preparedStatement.setString(4,customer.getPasswd());
	 			preparedStatement.setDouble(5,customer.getBalance());
	 			
	 			preparedStatement.setString(6,customer.getTransactions());		
	 			queryResult=preparedStatement.executeUpdate();
	 			return queryResult;
	 			
	 		}		catch(SQLException sqlException)
	 		{
	 			logger.error(sqlException.getMessage());
	 			sqlException.printStackTrace();
	 			throw new BankingException("Tehnical problem occured refer log");
	 		}
	 		finally
	 		{
	 			try 
	 			{
	 				preparedStatement.close();
	 				connection.close();
	 			}
	 			catch (SQLException sqlException) 
	 			{
	 				logger.error(sqlException.getMessage());
	 				throw new BankingException("Error in closing db connection");	
	 			}
	 		}	
	}

	public boolean printDetails(int accno) throws BankingException {
		Transfer t=new Transfer();
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.transfer_query2);
			preparedStatement.setLong(1,accno);	
			resultSet=preparedStatement.executeQuery();
						while(resultSet.next()) {
							t.setTransid(resultSet.getInt("transid"));
							t.setAccountno(resultSet.getLong("accountno"));
							t.setAmount(resultSet.getDouble("amount"));
							t.setTransfertype(resultSet.getString("transfertype"));
							t.setTransDate(resultSet.getDate("transDate"));
							System.out.println(t);
			}
		}catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new BankingException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new BankingException("Error in closing db connection");	
		}
	}return false;
}
	}


	
